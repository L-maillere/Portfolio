import ArgentBankImg from '../../assets/projectsPictures/argent-bank.png';
import SeventySevenEventsImg from '../../assets/projectsPictures/77events.png';
import NinaCarducciImg from '../../assets/projectsPictures/nina-carducci.png';
import KasaImg from '../../assets/projectsPictures/kasa.png';
import SophieBluelImg from '../../assets/projectsPictures/sophie-bluel.png';
import PrintItImg from '../../assets/projectsPictures/print-it.png';
import OhmyfoodImg from '../../assets/projectsPictures/ohmyfood.png';
import BookiImg from '../../assets/projectsPictures/booki.png';

const projectsData = [
  {
    "id": 1,
    "title": "Argent Bank",
    "description": "Argent Bank",
    "image": ArgentBankImg,
    "detailsUrl": "projects/argent-bank"
  },
  {
    "id": 2,
    "title": "77Events",
    "description": "77Events",
    "image": SeventySevenEventsImg,
    "detailsUrl": "projects/77events"
  },
  {
    "id": 3,
    "title": "Nina Carducci",
    "description": "Nina Carducci",
    "image": NinaCarducciImg,
    "detailsUrl": "projects/nina-carducci"
  },
  {
    "id": 4,
    "title": "Kasa",
    "description": "Kasa",
    "image": KasaImg,
    "detailsUrl": "projects/kasa"
  },
  {
    "id": 5,
    "title": "Sophie Bluel",
    "description": "Sophie Bluel",
    "image": SophieBluelImg,
    "detailsUrl": "projects/sophie-bluel"
  },
  {
    "id": 6,
    "title": "Print it",
    "description": "Print it",
    "image": PrintItImg,
    "detailsUrl": "projects/print-it"
  },
  {
    "id": 7,
    "title": "Ohmyfood",
    "description": "Ohmyfood",
    "image": OhmyfoodImg,
    "detailsUrl": "projects/ohmyfood"
  },
  {
    "id": 8,
    "title": "Booki",
    "description": "J'ai effectué l'intégration HTML/CSS pour Booki, un site fictif de réservation en ligne, en me concentrant sur une interface réactive et le respect des directives de conception.",
    "image": BookiImg,
    "detailsUrl": "projects/booki"
  }
];

export default projectsData;