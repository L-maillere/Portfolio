function ProjectDetails() {
  return (
    <div>
      <h1>ProjectDetails</h1>
    </div>
  )
}

export default ProjectDetails;