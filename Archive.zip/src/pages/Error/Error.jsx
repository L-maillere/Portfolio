function Error() {
  return (
    <section className="error">
      <h1>404</h1>
      <h2>Page non trouvée</h2>
    </section>
  );
}

export default Error;