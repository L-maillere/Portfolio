import ContactForm from "../../components/ContactForm/ContactForm";

function Contact() {
  return (
      <ContactForm />
  );
}

export default Contact;
